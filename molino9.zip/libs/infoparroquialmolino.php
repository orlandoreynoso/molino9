<div class="titulo-anuncios">
	<h3>Anuncios parroquiales</h3>
</div>
<div class="c-info" id="iglesia">
	<div id="div1">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>/horarios-de-misa">
			<img src="<?php echo IMAGES.'/horario-de-misa.jpg'; ?>" alt="">
			<span>Horarios de misa</span>
		</a>
	</div>
	<div id="div1">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>/boletin-parroquial/">
			<img src="<?php echo IMAGES.'/boletin-parroquial.jpg'; ?>" alt="">
			<span>Boletín Parroquial</span>
		</a>
	</div>
	<div id="div1">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>/editoriales/">
			<img src="<?php echo IMAGES.'/pluma.jpg'; ?>" alt="">
			<span>Editoriales</span>
		</a>
	</div>
	<div id="div1">
		<a href="http://www.mscguatemala.org/la-mision-msc">
			<img src="<?php echo IMAGES.'/misioneros.jpg'; ?>" alt="">
			<span>Misioneros del Sagrado Corazón</span>
		</a>
	</div>
</div>
