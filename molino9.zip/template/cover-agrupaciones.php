<div class="container">
  <div class="row">
    <div class="col-md-12">
      <article>
        <?php include (TEMPLATEPATH.'/libs/agrupaciones.php');  ?>
      </article>
    </div>
  </div>
</div>
