<div class="col-xs-12 col-sm-12 col-md-12">
  <div class="sm">
    <div class="ubicacion">
      <span class="icon fa fa-map-marker"></span>
      <span id="texto">Mixco, Guatemala</span>
    </div>
    <div class="search"><?php  get_search_form(); ?></div>
  </div>
</div>
