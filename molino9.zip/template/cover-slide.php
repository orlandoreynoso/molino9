
    <div class="row">
      <div class="col-md-12">
        <div>
        	<?php // if ( function_exists( 'easingslider' ) ) { easingslider( 1426 ); } ?>
        	<?php  echo do_shortcode("[metaslider id=1958]");  ?>
        </div>
      </div>
    </div>
