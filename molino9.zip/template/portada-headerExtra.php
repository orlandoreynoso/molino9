<div class="container">
  <div class="m-header">
    <div class="row">
      <div class="col-sm-6 col-md-4">
        <div class="ls">
          <?php logo(); ?>
        </div>
      </div>
      <div class="col-sm-6 col-md-8">
        <div class="sm">
          <div class="ubicacion">
            <span class="icon fa fa-map-marker"></span>
            <span id="texto">Mixco, Guatemala</span>
          </div>
          <div class="search"><?php  get_search_form(); ?></div>
        </div>
      </div>
    </div>
  </div>
</div>
