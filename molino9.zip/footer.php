
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="pie">
						<div class="group">
						<p>Parroquia Nuestra Señora del Sagrado Corazón</p>		
						<p>Zona 2 de Mixco, Guatemala</p>
						<p>Desarrollado por: <a href="http://www.orlandoreynoso.com">@orlandoreynoso</a></p>
						</div>
					</div>										
				</div>
			</div>
		</div>		
	</footer>
	<?php wp_footer(); ?>
</body>
</html>
